class Medicine:
    def __init__(self, name, manufacturer, price, stock):
        self.name = name
        self.manufacturer = manufacturer
        self.price = price
        self.stock = stock

    def __str__(self):
        return f"Medicine: {self.name}, Manufacturer: {self.manufacturer}, Price: {self.price}, Stock: {self.stock}"


class Customer:
    def __init__(self, name, customer_id):
        self.name = name
        self.customer_id = customer_id
        self.purchased_medicines = []

    def buy_medicine(self, medicine, quantity):
        if medicine.stock >= quantity:
            self.purchased_medicines.append((medicine, quantity))
            medicine.stock -= quantity
            return f"{self.name} has bought {quantity} {medicine.name}(s)."
        else:
            return f"Sorry, {medicine.name} is out of stock."

    def list_purchased_medicines(self):
        return [(medicine.name, quantity) for medicine, quantity in self.purchased_medicines]


class Drugshop:
    def __init__(self):
        self.medicines = []
        self.customers = []

    def add_medicine(self, medicine):
        self.medicines.append(medicine)

    def add_customer(self, customer):
        self.customers.append(customer)

    def list_available_medicines(self):
        return [medicine for medicine in self.medicines if medicine.stock > 0]

    def list_out_of_stock_medicines(self):
        return [medicine for medicine in self.medicines if medicine.stock == 0]

    def list_customers(self):
        return [customer.name for customer in self.customers]


if __name__ == "__main__":
    
    medicine1 = Medicine("Medicine1", "Manufacturer1", 10.0, 50)
    medicine2 = Medicine("Medicine2", "Manufacturer2", 15.0, 30)
    medicine3 = Medicine("Medicine3", "Manufacturer3", 20.0, 0)

    
    customer1 = Customer("John Mat", "C001")
    customer2 = Customer("Jane Smith", "C002")

    drugshop = Drugshop()

    drugshop.add_medicine(medicine1)
    drugshop.add_medicine(medicine2)
    drugshop.add_medicine(medicine3)

    drugshop.add_customer(customer1)
    drugshop.add_customer(customer2)

    print("Available Medicines:")
    for medicine in drugshop.list_available_medicines():
        print(medicine)
    print(customer1.buy_medicine(medicine1, 5))

    
    print("\nPurchased Medicines:")
    for medicine, quantity in customer1.list_purchased_medicines():
        print(f"{quantity} {medicine} purchased")

    print("\nOut of Stock Medicines:")
    for medicine in drugshop.list_out_of_stock_medicines():
        print(medicine)
